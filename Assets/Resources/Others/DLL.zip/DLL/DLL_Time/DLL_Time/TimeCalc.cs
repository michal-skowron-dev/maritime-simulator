﻿namespace DLL_Time
{
    /// <summary>
    /// Extracts hours or minutes from received slider value.
    /// </summary>
    public class TimeCalc
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="time">Slider value.</param>
        /// <returns>Returns hours from received slider value.</returns>
        public static ushort Hours(float time)
        {
            return (ushort)(time * 4 / 60);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="time">Slider value.</param>
        /// <returns>Returns minutes from received slider value.</returns>
        public static ushort Minutes(float time)
        {
            return (ushort)((time * 4) - (Hours(time) * 60));
        }
    }
}