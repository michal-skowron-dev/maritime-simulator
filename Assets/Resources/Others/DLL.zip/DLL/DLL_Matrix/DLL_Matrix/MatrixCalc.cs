﻿using System;

namespace DLL_Matrix
{
    /// <summary>
    /// Setting and checking matrix.
    /// </summary>
    public class MatrixCalc
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="matrix">Matrix to check.</param>
        /// <returns>Returns true if matrix is 4-dimensional.</returns>
        public static bool CheckMatrixDimension(double[,] matrix)
        {
            if (matrix.GetLength(0) != 4 && matrix.GetLength(1) != 4)
                return false;

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="positionX">Set position X.</param>
        /// <param name="positionY">Set position Y.</param>
        /// <param name="positionZ">Set position Z.</param>
        /// <param name="rotationX">Set rotationX X.</param>
        /// <param name="rotationY">Set rotationX Y.</param>
        /// <param name="rotationZ">Set rotationX Z.</param>
        /// <returns>Returns array of set parameters.</returns>
        public static double[] SetParameters(double positionX, double positionY, double positionZ, double rotationX, double rotationY, double rotationZ)
        {
            double[] array = new double[6];

            array[0] = positionX;
            array[1] = positionY;
            array[2] = positionZ;

            array[3] = rotationX;
            array[4] = rotationY;
            array[5] = rotationZ;

            return array;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="matrixA">First 4-dimensional matrix.</param>
        /// <param name="matrixB">Second 4-dimensional matrix.</param>
        /// <returns>Returns multiplied matrix.</returns>
        public static double[,] MultiplyMatrix(double[,] matrixA, double[,] matrixB)
        {
            if (CheckMatrixDimension(matrixA) && CheckMatrixDimension(matrixB))
            {
                double[,] result = new double[4, 4];

                for (ushort i = 0; i < 4; i++)
                {
                    for (ushort j = 0; j < 4; j++)
                    {
                        for (ushort k = 0; k < 4; k++)
                            result[i, j] += matrixA[i, k] * matrixB[k, j];
                    }
                }

                return result;
            }
            else
            {
                //Debug.Log("Incorrect matrix dimension in \"MultiplyMatrix\" function. 4x4 matrix required");
                return CreateMatrix("EMPTY", new double[6] { 0, 0, 0, 0, 0, 0 });
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="type">Operation type: "BASE"; "RX"; "RY"; "RZ".</param>
        /// <param name="value">Array with values to set into matrix.</param>
        /// <returns>Returns 4-dimensional matrix</returns>
        public static double[,] CreateMatrix(string type, double[] value)
        {
            if (type.Equals("BASE"))
            {
                return new double[4, 4]
                {
                    {1, 0, 0, value[0]},
                    {0, 1, 0, value[1]},
                    {0, 0, 1, value[2]},
                    {0, 0, 0, 1}
                };
            }
            else if (type.Equals("RX"))
            {
                return new double[4, 4]
                {
                    {1, 0, 0, 0},
                    {0, Math.Cos(value[3]), -Math.Sin(value[3]), 0},
                    {0, Math.Sin(value[3]), Math.Cos(value[3]), 0},
                    {0, 0, 0, 1}
                };
            }
            else if (type.Equals("RY"))
            {
                return new double[4, 4]
                {
                    {Math.Cos(value[4]), 0, Math.Sin(value[4]), 0},
                    {0, 1, 0, 0},
                    {-Math.Sin(value[4]), 0, Math.Cos(value[4]), 0},
                    {0, 0, 0, 1}
                };
            }
            else if (type.Equals("RZ"))
            {
                return new double[4, 4]
                {
                    {Math.Cos(value[5]), -Math.Sin(value[5]), 0, 0},
                    {Math.Sin(value[5]), Math.Cos(value[5]), 0, 0},
                    {0, 0, 1, 0},
                    {0, 0, 0, 1}
                };
            }
            else
            {
                return new double[4, 4]
                {
                    {0, 0, 0, 0},
                    {0, 0, 0, 0},
                    {0, 0, 0, 0},
                    {0, 0, 0, 0}
                };
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="matrix">4-dimensional matrix.</param>
        /// <returns>Returns array of angles parameters.</returns>
        public static double[] GetAngles(double[,] matrix)
        {
            if (CheckMatrixDimension(matrix))
            {
                double rx, ry, rz;
                rx = Math.Asin(matrix[3, 2]);

                if (rx < (Math.PI / 2))
                {
                    if (rx > (-Math.PI / 2))
                    {
                        rz = Math.Atan2(-matrix[1, 2], matrix[2, 2]);
                        ry = Math.Atan2(-matrix[3, 1], matrix[3, 3]);
                    }
                    else
                    {
                        rz = -Math.Atan2(-matrix[1, 3], matrix[1, 1]);
                        ry = 0;
                    }
                }
                else
                {
                    rz = Math.Atan2(matrix[1, 3], matrix[1, 1]);
                    ry = 0;
                }

                return new double[3] { rx, ry, rz };
            }
            else
            {
                //Debug.Log("Incorrect matrix dimension in \"GetAngles\" function. 4x4 matrix required");
                return new double[3] { 0, 0, 0 };
            }
        }
    }
}